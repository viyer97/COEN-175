void f(int x, int y, int z, int a)
{
    int x;			/* redeclaration of 'x' */
    int *y[10];			/* redeclaration of 'y' */
    int z, zz;			/* redeclaration of 'z' */
}
