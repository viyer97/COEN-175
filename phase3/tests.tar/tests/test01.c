int main(void)
{
    int x, y, z;

    {
	int x, y, z;

	{
	    void *x, *y[10], z;		/* 'z' has type void */
	}
    }
}
